module;

#include <string>
#include <vector>
#include <filesystem>
#include <fstream>
#include <sstream>
#include <unordered_set>
#include <stdexcept>

export module core:shader_files;

import :rhi;
import :file_system;

export namespace rendern
{
	using namespace FILE_UTILS;

	bool StartsWithTrimmed(std::string_view line, std::string_view token)
	{
		size_t idx = line.find_first_not_of(" \t");
		if (idx == std::string_view::npos)
		{
			return false;
		}
		return line.substr(idx).starts_with(token);
	}

	void ExpandTextIncludes(
		const fs::path& file,
		std::unordered_set<fs::path>& includeStack,
		std::vector<fs::path>& dependencies,
		std::string& output,
		bool isRoot,
		bool stripNestedVersion)
	{
		auto absPath = fs::weakly_canonical(file);
		if (includeStack.contains(absPath))
		{
			throw std::runtime_error("Recursive #include detected: " + absPath.string());
		}

		includeStack.insert(absPath);
		dependencies.push_back(absPath);

		const std::string source = ReadAllText(absPath);
		std::istringstream inputStream(source);

		std::string line;
		while (std::getline(inputStream, line))
		{
			if (stripNestedVersion && !isRoot && StartsWithTrimmed(line, "#version"))
			{
				output += "// (stripped) " + line + "\n";
				continue;
			}

			if (StartsWithTrimmed(line, "#include"))
			{
				const auto quote0 = line.find('"');
				const bool isQ0npos = (quote0 == std::string::npos);
				const auto quote1 = isQ0npos ? std::string::npos : line.find('"', quote0 + 1);
				if (isQ0npos || quote1 == std::string::npos || quote1 <= quote0 + 1)
				{
					throw std::runtime_error("Invalid #include syntax in: " + absPath.string());
				}

				const auto relatedName = line.substr(quote0 + 1, quote1 - (quote0 + 1));
				const auto includeName = absPath.parent_path() / fs::path(relatedName);

				output += "\n// --- begin include: " + includeName.string() + "\n";
				ExpandTextIncludes(includeName, includeStack, dependencies, output, false, stripNestedVersion);
				output += "// --- end include: " + includeName.string() + "\n\n";
			}
			else
			{
				output += line;
				output += "\n";
			}
		}

		includeStack.erase(absPath);
	}

	// Loads a text shader file and expands `#include "..."` recursively.
	TextFile LoadTextFileWithIncludes(const fs::path& path)
	{
		TextFile outputFile;
		std::unordered_set<fs::path> stack;
		ExpandTextIncludes(path, stack, outputFile.dpendencies, outputFile.text, true, false);
		return outputFile;
	}

	// Loads GLSL from file and expands `#include "..."` recursively.
	// - Included paths are resolved relative to the including file.
	// - Nested files must NOT contain `#version` (it will be stripped to avoid GLSL errors).
	TextFile LoadGLSLWithIncludes(const fs::path& path)
	{
		TextFile outputFile;
		std::unordered_set<fs::path> stack;
		ExpandTextIncludes(path, stack, outputFile.dpendencies, outputFile.text, true, true);
		return outputFile;
	}

	std::string MakeShaderDefineLine(std::string defineStr)
	{
		const auto equation = defineStr.find('=');
		if (equation != std::string::npos)
		{
			defineStr[equation] = ' ';
		}
		return std::string("#define ") + defineStr + "\n";
	}

	std::string BuildShaderDefinesBlock(const std::vector<std::string>& defines)
	{
		std::string definesBlock;
		definesBlock.reserve(defines.size() * 24);

		for (const auto& defineStr : defines)
		{
			definesBlock += MakeShaderDefineLine(defineStr);
		}

		return definesBlock;
	}

	std::string ApplyDefinesToHLSL(
		std::string_view source,
		const std::vector<std::string>& defines)
	{
		if (defines.empty())
		{
			return std::string(source);
		}

		std::string output = BuildShaderDefinesBlock(defines);
		output.append(source);
		return output;
	}

	// Inserts `#define ...` lines after `#version` (if present), otherwise prepends them.
	// Accepts entries like: "FOO", "USE_FOG=1" (the first '=' will be replaced by space).
	std::string AppplyDefinesToGLSL(
		std::string_view source, const std::vector<std::string>& defines)
	{
		if (defines.empty())
		{
			return std::string(source);
		}

		const std::string definesBlock = BuildShaderDefinesBlock(defines);

		// Find a version line
		const std::string_view verToken = "#version";
		const auto verPosition = source.find(verToken);
		if (verPosition != std::string_view::npos)
		{
			const auto endOfLine = source.find('\n', verPosition);
			if (endOfLine != std::string_view::npos)
			{
				std::string output;
				output.reserve(source.size() + definesBlock.size() + 1);
				output.append(source.substr(0, endOfLine + 1));
				output.append(definesBlock);
				output.append(source.substr(endOfLine + 1));
				return output;
			}
		}

		return definesBlock + std::string(source);
	}
}

