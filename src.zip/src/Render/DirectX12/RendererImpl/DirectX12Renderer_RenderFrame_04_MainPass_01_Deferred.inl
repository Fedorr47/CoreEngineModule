if (canDeferred)
{
#include "RendererImpl/DirectX12Renderer_RenderFrame_04_MainPass_01a_DeferredGeometryAndLighting.inl"
#include "RendererImpl/DirectX12Renderer_RenderFrame_04_MainPass_01b_DeferredPost.inl"
#include "RendererImpl/DirectX12Renderer_RenderFrame_04_MainPass_01c_DeferredTransparentAndSelection.inl"
}
else
{