﻿import core;
import std;


#define GLFW_INCLUDE_NONE
#include <GLFW/glfw3.h>

#if defined(_WIN32)
#define GLFW_EXPOSE_NATIVE_WIN32
#include <GLFW/glfw3native.h>
#include <windows.h>
#endif

static void GLFWErrorCallback(int error, const char* desc)
{
    std::cerr << "GLFW error " << error << ": " << (desc ? desc : "") << "\n";
}

static void TinySleep()
{
    std::this_thread::sleep_for(std::chrono::milliseconds(1));
}

int main()
{
    glfwSetErrorCallback(GLFWErrorCallback);

    if (!glfwInit())
    {
        std::cerr << "glfwInit failed\n";
        return 1;
    }

    glfwWindowHint(GLFW_CLIENT_API, GLFW_NO_API);

    const int W = 1280;
    const int H = 720;

    GLFWwindow* wnd = glfwCreateWindow(W, H, "CoreEngine DX12", nullptr, nullptr);
    if (!wnd)
    {
        std::cerr << "glfwCreateWindow failed\n";
        glfwTerminate();
        return 1;
    }

    try
    {
        // DX12 device + swapchain
        std::unique_ptr<rhi::IRHIDevice> device = rhi::CreateDX12Device();

#if defined(_WIN32)
        HWND hwnd = glfwGetWin32Window(wnd);
#else
        void* hwnd = nullptr;
#endif

        rhi::DX12SwapChainDesc sc{};
        sc.hwnd = (HWND)hwnd;
        sc.bufferCount = 2;
        sc.base.extent = rhi::Extent2D{ (std::uint32_t)W, (std::uint32_t)H };
        sc.base.backbufferFormat = rhi::Format::BGRA8_UNORM;
        sc.base.vsync = true;

        std::unique_ptr<rhi::IRHISwapChain> swapChain = rhi::CreateDX12SwapChain(*device, sc);

        // ResourceManager: STB decoder + DX12 uploader
        StbTextureDecoder decoder{};
        rendern::DX12TextureUploader uploader{ *device };
        rendern::JobSystemImmediate jobs{};
        rendern::RenderQueueImmediate rq{};

        TextureIO io{ decoder, uploader, jobs, rq };
        
        ResourceManager rm;

        // Load brick texture
        TextureProperties brickProps{};
        brickProps.filePath = (std::filesystem::path("textures") / "brick.png").string();
        brickProps.generateMips = true;
        brickProps.srgb = true;

        auto brickHandle = rm.LoadAsync<TextureResource>("brick", io, brickProps);

        // Renderer (cube.obj)
        rendern::RendererSettings rs{};
        rs.modelPath = std::filesystem::path("models") / "cube.obj";
        rendern::Renderer renderer{ *device, rs };

        rhi::TextureDescIndex brickDesc = 0;
 
        while (!glfwWindowShouldClose(wnd))
        {
            glfwPollEvents();

            rm.ProcessUploads<TextureResource>(io, 8, 32);

            rhi::TextureHandle brick{};
            if (auto tex = rm.Get<TextureResource>("brick"))
            {
                const auto& gpu = tex->GetResource();
                if (gpu.id != 0)
                    brick = rhi::TextureHandle{ (std::uint32_t)gpu.id };
            }

            if (brick && brickDesc == 0)
                brickDesc = device->AllocateTextureDesctiptor(brick);

            renderer.RenderFrame(*swapChain, brick, brickDesc);

            TinySleep();
        }

        renderer.Shutdown();

        if (brickDesc != 0)
            device->FreeTextureDescriptor(brickDesc);

        glfwDestroyWindow(wnd);
        glfwTerminate();
        return 0;
    }
    catch (const std::exception& e)
    {
        std::cerr << "Fatal: " << e.what() << "\n";
        glfwDestroyWindow(wnd);
        glfwTerminate();
        return 2;
    }
}
